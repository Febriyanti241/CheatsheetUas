import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class MinTest {
    @Test
    void testMin() {
        int x = 23;
        int y = 24;
        int a = 2;
        int b = 1;

        assertEquals(23, Min.min(x,y));
        assertEquals(1, Min.min(a,b));
    }
}
