import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

public class Declarative12aTest {
    @Test
    void testOlahArraySiang() {
        List<Integer> input = new ArrayList<>();
        input.add(1);
        input.add(2);
        input.add(3);
        input.add(4);
        input.add(5);
        input.add(6);
        input.add(7);


        List<Integer> expected = new ArrayList<>();
        expected.add(300);
        expected.add(600);

        assertEquals(expected.toString(), Declarative12a.olahArraySiang(input).toString());
    }
}
