
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class MaxTest {
    @Test
    void testMax() {
        int x = 23;
        int y = 24;
        int a = 2;
        int b = 1;

        assertEquals(24, Max.max(x,y));
        assertEquals(2, Max.max(a,b));
    }
}
