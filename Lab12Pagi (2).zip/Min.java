public class Min {
 /** Return the maximum between two objects */
 public static <E extends Comparable<E>> E min(E o1, E o2) {
    if (o1.compareTo(o2) < 0)
      return o1;
    else
      return o2;
  }

    public static void main(String[] args) {
      int x = 23;
      String text = "Welcome";
      int y = 24;

      System.out.println(min(y,x));
    }   
}