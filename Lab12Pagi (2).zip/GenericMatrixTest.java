import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

public class GenericMatrixTest {
    @Test
    void testCheckSize() {
        IntegerMatrix im = new IntegerMatrix();
        Integer[][] m1 = new Integer[3][5];
        Integer[][] m2 = new Integer[3][5];
        Integer[][] m3 = new Integer[4][5];

        assertTrue(im.checkSize(m1, m2));
        assertFalse(im.checkSize(m2, m3));
    }

    @Test
    void testCheckSize01() {
        RationalMatrix im = new RationalMatrix();
        Rational[][] m1 = new Rational[3][5];
        Rational[][] m2 = new Rational[3][5];
        Rational[][] m3 = new Rational[4][5];

        assertTrue(im.checkSize(m1, m2));
        assertFalse(im.checkSize(m2, m3));
    }
}
