import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Declarative12a {
    public static List<Integer> olahArraySiang(List<Integer> input) {
        return input.stream()
        .filter(n -> n%3==0)
        .map(n -> n*100)
        .collect(Collectors.toList());
    }
}
