package burhanfess.users;

public class Cosmic extends User {
    public Cosmic(int id, String username, String password) {
        super(id, username, password);
    }
    public Cosmic(String username, String password) {
        super(username, password);
    }

    @Override
    public String getRole() {
        return "Cosmic";
    }
}
