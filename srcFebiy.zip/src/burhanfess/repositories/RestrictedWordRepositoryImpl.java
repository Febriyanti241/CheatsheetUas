package burhanfess.repositories;

import java.util.ArrayList;
import java.util.List;

public class RestrictedWordRepositoryImpl {
    MenfessRepository menfessRepository;
    private List <String> restrictedWords = new ArrayList();
    public static RestrictedWordRepository restrictedWordRepository;
    
    public RestrictedWordRepositoryImpl(){

    }
    public MenfessRepository getInstance(){
        return menfessRepository;
    }
    public List<String> getAllRestristedWords(){
        return restrictedWords;
    }
    public void addRestrictedWord(String word){
        restrictedWords.add(word);

    }
    public boolean isRestrictedWordExisted(String word){
        for (String kata : restrictedWords){
            if (word.contains(kata)){
                return false;
            }
            
        }
        return true;
    }
}
