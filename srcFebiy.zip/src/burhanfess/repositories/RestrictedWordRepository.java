package burhanfess.repositories;

import java.util.List;

public interface RestrictedWordRepository {
    public Boolean isRestrictedWordExisted(String word);
    public void addRestrictedWord(String word);
    public List<String> getAllRestrictedWords();
    
}
