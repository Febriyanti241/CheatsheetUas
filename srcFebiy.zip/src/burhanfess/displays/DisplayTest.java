package burhanfess.displays;

import org.junit.jupiter.api.Test;

public class DisplayTest {
    @Test
    void testRunAndGetUsername() {

    }

    @Test
    void testShowCurrentDate() {

    }

    @Test
    void testShowFooter() {

    }

    @Test
    void testShowHeader() {

    }

    @Test
    void testShowMenu() {

    }
}
