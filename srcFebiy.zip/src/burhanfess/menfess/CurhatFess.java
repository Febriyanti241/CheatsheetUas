package burhanfess.menfess;

import burhanfess.users.User;

public class CurhatFess extends Menfess {
    public CurhatFess(User user, String content) {
        super(user, content);
    }
    public CurhatFess(User user, String content, String time, boolean isHidden) {
        super(user, content, time, isHidden);
    }

    @Override
    public String getType() {
        return "Curhat";
    }
}
