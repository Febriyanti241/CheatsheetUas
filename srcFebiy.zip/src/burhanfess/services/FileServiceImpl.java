package burhanfess.services;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import burhanfess.menfess.ConfessFess;
import burhanfess.menfess.CurhatFess;
import burhanfess.menfess.Menfess;
import burhanfess.menfess.PromosiFess;
import burhanfess.repositories.MenfessRepository;
import burhanfess.repositories.MenfessRepositoryImpl;
import burhanfess.repositories.UserRepository;
import burhanfess.repositories.UserRepositoryImpl;
import burhanfess.users.Admin;
import burhanfess.users.Cosmic;
import burhanfess.users.User;

public class FileServiceImpl implements FileService{

    private final UserRepositoryImpl userRepository = UserRepositoryImpl.getInstance();
    private final MenfessRepositoryImpl menfessRepository = MenfessRepositoryImpl.getInstance();
    private final String fileNameUser = "UserDB.txt";
    private final String fileMenfess = "Menfess.txt";
    

    @Override
    public void saveUsers() throws IOException {
        List<User> listUser = userRepository.getAllUsers();
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(fileNameUser))){
            for(User user : listUser){
                String users = user.getId()+"%"+user.getUsername() +"%"+ user.getPassword() + "%" + user.getRole();
                writer.write(users);
                writer.newLine();
            }
        }
    }

    @Override
    public void loadUsers() throws FileNotFoundException, IOException {
        List<User> listUser = userRepository.getAllUsers();
        try(BufferedReader reader = new BufferedReader(new FileReader(fileNameUser))){
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userArr = line.split("%");
                User user = null;
                if(userArr[3].equalsIgnoreCase("admin")){
                    user = new Admin(Integer.parseInt(userArr[0]), userArr[1], userArr[2]);
                }else{
                    user = new Cosmic(Integer.parseInt(userArr[0]), userArr[1], userArr[2]);
                }
                userRepository.addUser(user);
            }
        }
    }

    @Override
    public void saveMenfess() {
        List<Menfess> listMenfessesHidden = menfessRepository.getAllHiddenMenfesses();
        List<Menfess> listMenfessesUnhidden = menfessRepository.getAllUnhiddenMenfesses();
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(fileMenfess))){
            for(Menfess m : listMenfessesHidden){
                if(m instanceof ConfessFess){
                    String line = m.getId()+"%"+m.getUser().getUsername()+"%"+m.getContent()+"%"+m.getTime()+"%"+m.isHidden()+"%"+m.getType()+"%"+((ConfessFess)m).getReceiver().getUsername();
                    writer.write(line);
                    writer.newLine();
                }else{
                    String line = m.getId()+"%"+m.getUser().getUsername()+"%"+m.getContent()+"%"+m.getTime()+"%"+m.isHidden()+"%"+m.getType();
                    writer.write(line);
                    writer.newLine();
                }
            }
            for(Menfess m : listMenfessesUnhidden){
                if(m instanceof ConfessFess){
                    String line = m.getId()+"%"+m.getUser().getUsername()+"%"+m.getContent()+"%"+m.getTime()+"%"+m.isHidden()+"%"+m.getType()+"%"+((ConfessFess)m).getReceiver().getUsername();
                    writer.write(line);
                    writer.newLine();
                }else{
                    String line = m.getId()+"%"+m.getUser().getUsername()+"%"+m.getContent()+"%"+m.getTime()+"%"+m.isHidden()+"%"+m.getType();
                    writer.write(line);
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void loadMenfess() {
        // List<Menfess> listUser = userRepository.getAllUsers();
        // try(BufferedReader reader = new BufferedReader(new FileReader(fileNameUser)))

        try(BufferedReader reader = new BufferedReader(new FileReader(fileNameUser))){
            String line;
            while ((line = reader.readLine()) != null) {
                String[] menfessArr = line.split("%");
                Menfess menfess = null;
                if(menfessArr[5].equalsIgnoreCase("Confession")){
                    User pengirim = userRepository.getUserByUsername(menfessArr[1]);
                    User receiver = userRepository.getUserByUsername(menfessArr[6]);
                    menfess = new ConfessFess(pengirim, menfessArr[2], menfessArr[3], Boolean.parseBoolean(menfessArr[4]), receiver);
                }else if(menfessArr[5].equalsIgnoreCase("Curhat")){
                    User pengirim = userRepository.getUserByUsername(menfessArr[1]);
                    menfess = new CurhatFess(pengirim, menfessArr[2], menfessArr[3], Boolean.parseBoolean(menfessArr[4]));
                }else{
                    User pengirim = userRepository.getUserByUsername(menfessArr[1]);
                    menfess = new PromosiFess(pengirim, menfessArr[2], menfessArr[3], Boolean.parseBoolean(menfessArr[4]));
                }
                menfessRepository.addMenfess(menfess);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
