package burhanfess.services;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface FileService {
    
    public void saveUsers() throws IOException;
    public void loadUsers() throws FileNotFoundException, IOException;
    public void saveMenfess();
    public void loadMenfess();

    
}
