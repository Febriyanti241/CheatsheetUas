package burhanfess.exceptions;

public class MenfessNotFoundException extends RuntimeException {
    public MenfessNotFoundException(String message) {
        super(message);
    }
}
