import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class EightsTest {

    private static final String TEST_FILE = "test-scores.txt";

    @AfterEach
    void cleanup() {
        // hapus file uji setelah tiap test
        new File(TEST_FILE).delete();
    }

    @Test
    void testLoadHighScores_FileNotExist_ShouldReturnEmptyMap() {
        // pastikan file belum ada
        new File(TEST_FILE).delete();

        Map<String,Integer> map = Eights.loadHighScores(TEST_FILE);
        assertNotNull(map);
        assertTrue(map.isEmpty(), "Map harus kosong kalau file tidak ada");
    }

    @Test
    void testLoadHighScores_ValidFile_ShouldParseEntries() throws IOException {
        // siapkan file dengan dua baris valid
        try (BufferedWriter w = new BufferedWriter(new FileWriter(TEST_FILE))) {
            w.write("Alice 3\n");
            w.write("Bob 5\n");
        }

        Map<String,Integer> map = Eights.loadHighScores(TEST_FILE);
        assertEquals(2, map.size(), "Harus terbaca 2 entry");
        assertEquals(3, map.get("Alice"), "Nilai Alice harus 3");
        assertEquals(5, map.get("Bob"),   "Nilai Bob harus 5");
    }

    @Test
    void testSaveHighScores_ThenLoad_ShouldRoundTrip() {
        // siapkan map input
        Map<String,Integer> input = new HashMap<>();
        input.put("Carol", 7);
        input.put("Dave", 2);

        // simpan ke file
        Eights.saveHighScores(TEST_FILE, input);

        // load ulang dan bandingkan
        Map<String,Integer> loaded = Eights.loadHighScores(TEST_FILE);
        assertEquals(input.size(),   loaded.size(),   "Jumlah entry harus sama");
        assertEquals(input.get("Carol"), loaded.get("Carol"), "Carol harus 7");
        assertEquals(input.get("Dave"),  loaded.get("Dave"),  "Dave harus 2");
    }
}