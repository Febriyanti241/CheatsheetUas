import java.io.IOException;

public class ExceptionFormatTidakSesuai extends IOException {
    public ExceptionFormatTidakSesuai(String message){
        super(message);
    }   
}