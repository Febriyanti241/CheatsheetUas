import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


/**
 * Simulates a game of Crazy Eights.
 * See https://en.wikipedia.org/wiki/Crazy_Eights.
 */

public class Eights {

    private int banyakPermainan;
    private List <Player> listPemain;
    private Hand drawPile;
    private Hand discardPile;
    private Scanner in;
    public static Map<String, Integer> highScores;

    /**
     * Initializes the state of the game.
     */
    public Eights() {
        this.in = new Scanner(System.in);
    }

    public void initGame(){
        Deck deck = new Deck("Deck");
        deck.shuffle();

        for(Player pemain: listPemain){
            pemain.newHand();
            deck.deal(pemain.getHand(), 5);
        }

        // turn one card face up
        discardPile = new Hand("Discards");
        deck.deal(discardPile, 1);

        // put the rest of the deck face down
        drawPile = new Hand("Draw pile");
        deck.dealAll(drawPile);
    }

    /**
     * Returns true if either hand is empty.
     */
    public boolean isDone() {
        for(Player pemain: listPemain){
            if(pemain.getHand().isEmpty()) return true;
        }
        return false;
    }
    /**
     * Moves cards from the discard pile to the draw pile and shuffles.
     */
    public void reshuffle() {
        // save the top card
        Card prev = discardPile.popCard();

        // move the rest of the cards
        discardPile.dealAll(drawPile);

        // put the top card back
        discardPile.addCard(prev);

        // shuffle the draw pile
        drawPile.shuffle();
    }

    /**
     * Returns a card from the draw pile.
     */
    public Card drawCard() {
        if (drawPile.isEmpty()) {
            reshuffle();
        }
        return drawPile.popCard();
    }

    /**
     * Switches players.
     */
    public Player nextPlayer(Player current) {
        int pointer =0;
        for(int i=0; i<listPemain.size(); i++){
            if(listPemain.get(i).equals(current)){
                pointer = i+1;
            }
        }
        if(pointer == listPemain.size()){
            return listPemain.get(0);
        }
        return listPemain.get(pointer);
    }

    /**
     * Displays the state of the game.
     */
    public void displayState(Player current) {
        current.display();
        discardPile.display();
        System.out.println("Draw pile: " + drawPile.size() + " cards");
    }

    /**
     * One player takes a turn.
     */
    public void takeTurn(Player player) {
        Card prev = discardPile.lastCard();
        Card next = null;
        if(player instanceof HumanPlayer){
            next = ((HumanPlayer) player).play(this, prev, in);
            System.out.println(player.getName() + " plays " + next);
            System.out.println();
        } else if(player instanceof AIPayerAdvance){
            next = ((AIPayerAdvance) player).play(this, prev);
            System.out.println(player.getName() + " plays " + next);
            System.out.println();
            in.nextLine();
        } else if(player instanceof AIPlayerLast){
            next = ((AIPlayerLast) player).play(this, prev);
            System.out.println(player.getName() + " plays " + next);
            System.out.println();
            in.nextLine();
        }
        
        discardPile.addCard(next);            
    }

    /**
     * Plays the game.
     */
    public void playGame() {
        while(banyakPermainan!=0){
            Player winner = null;
            initGame();
            Player player = listPemain.get(0);
            // keep playing until there's a winner
            while (!isDone()) {
                displayState(player);
                takeTurn(player);
                player = nextPlayer(player);
            }

            for(Player pemain: listPemain){
                if(pemain.getHand().isEmpty()) {
                    winner = pemain;
                    // update skor pemenang inline
                    highScores.put(winner.getName(), highScores.getOrDefault(winner.getName(), 0) + 1);
                }
            }            
            for(Player pemain: listPemain){
                pemain.setScore();
            }
            banyakPermainan-=1;
        }
        
    }

    public void setBanyakPermainan(int banyakPermainan){
        this.banyakPermainan = banyakPermainan;
    }

    public void setPlayer(List <Player> listPemain){
        this.listPemain = listPemain;
    }
    
    
    public static Map<String, Integer> loadHighScores(String fileName) {
        Map<String, Integer> scores = new HashMap<>();
        File file = new File(fileName);
        if (!file.exists()) return scores;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts.length != 2) throw new ExceptionFormatTidakSesuai("Format satu baris tidak sesuai");
                scores.put(parts[0], Integer.parseInt(parts[1]));
            }
        } catch (FileNotFoundException e) {
            System.out.println("Exception: File not found");
        } catch (NumberFormatException e) {
            System.out.println("Exception: Ada score yang bukan angka");
        } catch (ExceptionFormatTidakSesuai e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return scores;
    }

    public static void saveHighScores(String fileName, Map<String, Integer> scores) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Map.Entry<String, Integer> entry : scores.entrySet()) {
                writer.write(entry.getKey() + " " + entry.getValue());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }

    /**
     * Main: prompt permainan & update skor, dengan metode file terpisah.
     */
    public static void main(String[] args) throws IOException {
        String hsFile = "highscores-eight.txt";
        highScores = loadHighScores(hsFile);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Berapa kali ingin bermain?");
        int jumlahMain = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Berapa orang yang ingin bermain?");
        int banyakPemain = scanner.nextInt();
        scanner.nextLine();

        List<Player> players = new ArrayList<>();
        for (int i = 0; i < banyakPemain; i++) {
            System.out.printf("Pilih tipe Player %d (1. Manusia 2. AI)%n", i + 1);
            int tipe = scanner.nextInt(); scanner.nextLine();
            if (tipe == 1) {
                System.out.println("Masukkan nama player:");
                players.add(new HumanPlayer(scanner.nextLine()));
            } else {
                System.out.println("Masukkan tipe AI (1. Last 2. Advanced)");
                int tAI = scanner.nextInt(); scanner.nextLine();
                players.add(tAI == 1 ? new AIPlayerLast(i) : new AIPayerAdvance(i));
            }
        }

        Eights game = new Eights();
        game.setPlayer(players);
        game.setBanyakPermainan(jumlahMain);
        game.playGame();

        
        saveHighScores(hsFile, highScores);
    }
}